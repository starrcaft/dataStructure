package controller;

public class DS04_201603867_조성환 {

    public static void main(String[] args){
        AppController appController= new AppController();
        appController.run();
    }
}
